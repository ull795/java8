package java5;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentBeen student  = new StudentBeen();
		student.setName("ullas");
		student.setId(1);
		student.setCourse("java");
		System.out.println(student.getName());
		System.out.println(student.getId());
		System.out.println(student.getCourse());
		

	}

}
