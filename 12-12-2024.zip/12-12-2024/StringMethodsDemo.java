package java5;

public class StringMethodsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="software developer";
		
		System.out.println(s.length());
		System.out.println("__________________________________");
		System.out.println(s.toUpperCase());
		System.out.println("__________________________________");
		System.out.println(s.toLowerCase());
		System.out.println("__________________________________");
		System.out.println(s.contains(s));
		System.out.println("__________________________________");
		System.out.println(s.startsWith("d"));
		System.out.println("__________________________________");
		System.out.println(s.concat("in Infosys"));
	}

}
